Länk till mitt webbadressen: https://company-blog.onrender.com

<!-- # Vad är Content Delivery Network (CDN) ?

CDN är ett sätt att optimera prestandan på din webbplats. Implementering av CDN har flera fördelar som exempelvis snabbare laddningstider, bättre stabilitet och bättre säkerhet. Kortfattat består CDN av distribuererade servrar som hjälper till att öka stabilitet och prestanda på din webbplats. Detta är oavsett var i världen som användaren befinner sig. Skulle servern gå ner så kan det fortfarande fungera då det finns på olika ställen. Det finns flera olika CDN-leverantörer att välja mellan. Några populära CDN-leverantörer är Cloudfare, Akamai och Amazon CloudFront. När du väljer CDN-leverantör är det viktigt att kontrollera att de kan erbjuda en bättre snabbhet än vad du för närvarande har. Det är även bra att jämföra pris och kundsupport hos olika CDN-leverantörer.

# Monitoring:
En av fördelarna med CDN är att du kan kolla övervaka vad som händer via CDN logs. Via CDN logs kan du se olika detaljer som status, tid, IP-adress och annan nödvändig information från besökare på din websida. Detta hjälper dig att få en bättre överblick över hur websajten fungerar. Du kan till exempel lättare upptäcka problem med sajten samt att CDN logs gör det lättare att upptäcka säkerhetshot. Pålitliga tjänster som erbjuder mointoring är bland annat Pingdom och Scout APM. Det går även att få notifikationer via sms eller e-post om tjänsten skulle bli otillgänglig eller om den skulle börja gå långsamt. Sammanfattningsvis går det att få en bättre överblick över tjänsten och hur den fungerar. -->

